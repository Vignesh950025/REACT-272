import React from 'react';
export const WithProductList=(WrapperComponent,productList)=>
{
   return ()=><WrapperComponent productList={productList}/>;
};