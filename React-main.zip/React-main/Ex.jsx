import React from "react";
import './style.css';
export default function Hello()
{
    return(
        <h1 style={{color:'red'}}>Hello</h1>
    )
}