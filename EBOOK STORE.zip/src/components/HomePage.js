import React, { useContext, useState } from "react";
import { useNavigate } from "react-router-dom"; 
import { CartContext } from "../components/CartContext";
import "./HomePage.css";

const HomePage = () => {
  const { cart, addToCart } = useContext(CartContext);  
  const navigate = useNavigate();
  const [isMoreMenuOpen, setIsMoreMenuOpen] = useState(false);  

  const toggleMoreMenu = () => {
    setIsMoreMenuOpen(!isMoreMenuOpen);  
  };

  const products = [
    { id: 1, name: " Antimatter Blues: A Mickey7 Novel", price: 199.99, image: "https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcTy294ALJiJ9DO6Qx6nBZml7FA7tkm_Lc1XeHroX683cJ2MhWu-d0zU4OzEXe6i5_G2nbiG346A2yX_QoWMKp57CIWI3Oyej620ETYFgno" },
    { id: 2, name: "Harry Potter And The Philosophers Stone", price: 29.99, image: " https://images.meesho.com/images/products/436823092/wycvn_1200.jpg" },
    { id: 3, name: "The Cruel Prince', category", price: 899.99, image: "https://m.media-amazon.com/images/I/91REBdqE+oL.jpg" },
    { id: 4, name: "Sorcery Of Thorns", price: 129.99, image: "https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcQJrUwAQhTi8sH18-xtI4WeavoW1Us5hc4uLra1uMhvym4RyWAM4lEzRFdHgk-FpBmTQwpp1cFsnaS2BvQVlF25LXkOvq0aKKn2lOZUuwE" },
    { id: 5, name: "Serpant Gift", price: 499.99, image: "https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcR54v7d73cNzSQUZFACMqaVrV-NbYQ26qNmqsJSSfXjFlVIa2U6EalMDvlLUudJRXjxgDea_HpunfErOjSWZ8KrVk7uGCfEhrvcToN1LPyuY-U7Lith9OX8dQ" },
    { id: 6, name: "Atomic Habits", price: 19.99, image: "https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcR7BJsA4SW0Ks6vsZamOBP7T_PW-uWBBFKHVOY35bcpprC1-tlilN5Z-0VmSnIJ83gFxtwfpXmSIKtNqUdKxldHzWhRNZwKiWspCiJjzoHX2Y7Nd-CWyOXL" },
    { id: 7, name: "Sapiens : A Brief History of Humankind", price: 299.99, image: "https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcSKttHrnofiLTmZCWesdDGIbcJMKvAYUpcqOWrG-mOor9OmaWpTnyFDI3VaspTZfsnNWR3KVyv7U-uDEcBUEu0izrEAqn35SSRgtkIxdTeuyGKitIrQ585oJQ" },
    { id: 8, name: "The Phychology Of Money", price: 499.99, image: "https://images.meesho.com/images/products/444078641/saxsc_1200.jpg" },
    { id: 9, name: "The New Psychology Of Success", price: 79.99, image: "https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcQfH3JRGSoO93Ed5STsNpZ_b9pEBEvgQlJMu6jv_dRfZN9XJwT5CY_2IwpF_e1WMe62bVMC4O9Ovn-cdiVl6Pn0FzpMvGXrX6LZDeHas0Jwe9JNN0MGRqLcsQ" },
    { id: 10, name: "The Healing Power Of EFT and Energy Psychology", price: 699.99, image: "https://m.media-amazon.com/images/I/61vR05dM1tL._UF1000,1000_QL80_.jpg" }
  ];

  // Handle Buy Now button click - adds to cart and navigates to checkout
  const handleBuyNow = (product) => {
    addToCart(product);
    navigate("/checkout");
  };

  // Handle Add to Cart button click
  const handleAddToCart = (product) => {
    addToCart(product);
    alert(`${product.name} added to cart!`);
  };

  return (
    <div className="homepage-container">
      <header className="navbar">
        <div className="logo">My E-Bookstroe</div>
        <div className="search-bar">
          <input type="text" placeholder="Search for books, novels, and more" />
        </div>
        <div className="nav-links">
          <a href="/login" className="login-button">Login</a>
          <div className="more-button-container">
            <button className="more-button" onClick={toggleMoreMenu}>More</button>
            {isMoreMenuOpen && (
              <div className="more-menu">
                <a href="/orders">Orders</a>
                <a href="/wishlist">Wishlist</a>
                <a href="/support">Support</a>
              </div>
            )}
          </div>
          {/* Displaying cart count using cart.length */}
          <a href="/cart" className="cart-button">Cart ({cart.length})</a>
        </div>
      </header>

      <div className="banner">
        <img src="https://img.freepik.com/free-photo/modern-bookstore-showcasing-rows-vibrant-books_60438-3565.jpg" alt="Banner" />
        <div className="banner-text">
          <h1>Diwali Offers!!  upto  75%</h1>
          <button className="shop-now-button">Shop Now</button>
        </div>
      </div>

      <div className="products-section">
        <h2>Featured Products</h2>
        <div className="product-list">
          {products.map((product) => (
            <div className="product-card" key={product.id}>
              <img src={product.image} alt={product.name} />
              <h3>{product.name}</h3>
              <p>${product.price.toFixed(2)}</p>
              <div className="product-actions">
                <button className="buy-button" onClick={() => handleBuyNow(product)}>
                  Buy Now
                </button>
                <button className="add-to-cart-button" onClick={() => handleAddToCart(product)}>
                  Add to Cart
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default HomePage;
