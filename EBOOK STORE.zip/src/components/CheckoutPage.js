import React, { useContext, useState } from "react";
import { CartContext } from "../components/CartContext";
import { useNavigate } from "react-router-dom";
import "./CheckoutPage.css";

const CheckoutPage = () => {
  const { cart } = useContext(CartContext);
  const [address, setAddress] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("");
  const navigate = useNavigate();

  const handlePlaceOrder = () => {
    if (address && paymentMethod) {
      // Calculate total price
      const totalPrice = cart.reduce((total, product) => total + product.price, 0).toFixed(2);

      // Create a summary of the order
      const orderSummary = cart.map(product => `${product.name} - $${product.price.toFixed(2)}`).join("\n");

      // Show the alert with the order details
      alert(`Order placed successfully!\n\nAddress: ${address}\n\nProducts:\n${orderSummary}\n\nTotal: $${totalPrice}`);

      // Navigate to home after placing the order
      navigate("/");
    } else {
      alert("Please fill in all the details.");
    }
  };

  return (
    <div className="checkout-page">
      <header className="navbar">
        <div className="logo">My E-Commerce</div>
      </header>

      <div className="checkout-container">
        <h2>Checkout</h2>

        <div className="address-section">
          <h3>Delivery Address</h3>
          <textarea
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            placeholder="Enter your delivery address"
            rows="4"
          ></textarea>
        </div>

        <div className="payment-section">
          <h3>Payment Method</h3>
          <div className="payment-options">
            <label>
              <input
                type="radio"
                value="credit-card"
                checked={paymentMethod === "credit-card"}
                onChange={() => setPaymentMethod("credit-card")}
              />
              Credit Card
            </label>
            <label>
              <input
                type="radio"
                value="debit-card"
                checked={paymentMethod === "debit-card"}
                onChange={() => setPaymentMethod("debit-card")}
              />
              Debit Card
            </label>
            <label>
              <input
                type="radio"
                value="cod"
                checked={paymentMethod === "cod"}
                onChange={() => setPaymentMethod("cod")}
              />
              Cash on Delivery
            </label>
          </div>
        </div>

        <div className="order-summary">
          <h3>Order Summary</h3>
          {cart.map((product) => (
            <div className="order-item" key={product.id}>
              <img src={product.image} alt={product.name} />
              <div>
                <h4>{product.name}</h4>
                <p>${product.price.toFixed(2)}</p>
              </div>
            </div>
          ))}
          <button className="place-order-button" onClick={handlePlaceOrder}>
            Place Order
          </button>
        </div>
      </div>
    </div>
  );
};

export default CheckoutPage;
