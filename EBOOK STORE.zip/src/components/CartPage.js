import React, { useContext } from "react";
import { CartContext } from "../components/CartContext";
import { Link } from "react-router-dom";
import "./CartPage.css";

const CartPage = () => {
  const { cart, removeFromCart } = useContext(CartContext);

  const handleRemove = (productId) => {
    removeFromCart(productId);
  };

  return (
    <div className="cart-page">
      <header className="navbar">
        <div className="logo">My E-Commerce</div>
        <div className="nav-links">
          <Link to="/" className="nav-link">Home</Link>
          <Link to="/login" className="nav-link">Login</Link>
          <Link to="/" className="nav-link">More</Link>
        </div>
      </header>

      <div className="cart-container">
        <h2>Shopping Cart</h2>
        {cart.length === 0 ? (
          <div className="empty-cart">
            <p>Your cart is empty.</p>
            <Link to="/" className="shop-link">Shop Now</Link>
          </div>
        ) : (
          <div className="cart-items">
            {cart.map((product) => (
              <div className="cart-item" key={product.id}>
                <img src={product.image} alt={product.name} className="cart-item-image" />
                <div className="cart-item-info">
                  <h3>{product.name}</h3>
                  <p className="cart-item-price">${product.price.toFixed(2)}</p>
                  <button className="remove-button" onClick={() => handleRemove(product.id)}>Remove</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default CartPage;
